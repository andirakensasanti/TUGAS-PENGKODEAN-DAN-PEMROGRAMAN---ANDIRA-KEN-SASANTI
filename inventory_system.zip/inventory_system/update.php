<?php
include "config.php";
$data = json_decode(file_get_contents("php://input"));

$sql = "UPDATE products SET stock='$data->stock' WHERE id='$data->id'";
$conn->query($sql);
?>