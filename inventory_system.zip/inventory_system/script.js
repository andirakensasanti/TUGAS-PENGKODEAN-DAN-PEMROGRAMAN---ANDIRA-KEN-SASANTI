document.addEventListener("DOMContentLoaded", fetchProducts);

function fetchProducts() {
    fetch("fetch.php")
        .then(response => response.json())
        .then(data => {
            let table = document.getElementById("productTable");
            table.innerHTML = "";
            data.forEach(product => {
                table.innerHTML += `
                    <tr>
                        <td>${product.id}</td>
                        <td>${product.name}</td>
                        <td>${product.stock}</td>
                        <td>${product.price}</td>
                        <td>${product.category}</td>
                        <td>
                            <button onclick="updateStock(${product.id})">Update</button>
                            <button onclick="deleteProduct(${product.id})">Hapus</button>
                        </td>
                    </tr>
                `;
            });
        });
}

function searchProduct() {
    let search = document.getElementById("search").value.toLowerCase();
    let rows = document.querySelectorAll("tbody tr");

    rows.forEach(row => {
        let name = row.children[1].innerText.toLowerCase();
        row.style.display = name.includes(search) ? "" : "none";
    });
}

function addProduct() {
    let name = prompt("Masukkan Nama Produk:");
    let stock = prompt("Masukkan Jumlah Stok:");
    let price = prompt("Masukkan Harga:");
    let category = prompt("Masukkan Kategori:");

    fetch("insert.php", {
        method: "POST",
        body: JSON.stringify({ name, stock, price, category }),
        headers: { "Content-Type": "application/json" }
    }).then(() => fetchProducts());
}

function deleteProduct(id) {
    if (confirm("Yakin ingin menghapus?")) {
        fetch("delete.php?id=" + id)
            .then(() => fetchProducts());
    }
}

function updateStock(id) {
    let stock = prompt("Masukkan stok baru:");
    fetch("update.php", {
        method: "POST",
        body: JSON.stringify({ id, stock }),
        headers: { "Content-Type": "application/json" }
    }).then(() => fetchProducts());
}