<?php
include "config.php";
$data = json_decode(file_get_contents("php://input"));

$sql = "INSERT INTO products (name, stock, price, category) VALUES ('$data->name', '$data->stock', '$data->price', '$data->category')";
$conn->query($sql);
?>